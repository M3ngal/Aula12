package ex1;

import java.sql.Connection;
import java.sql.SQLException;

public class Teste{
    public static void main(String[] args){
        Connection conn = null;

        try{
            ConexaoBD bd = new ConexaoBD();
            conn = bd.conectar();
            Professor professor1 = new Professor("B", 35, 1);
            professor1.incluir(conn);
            System.out.println(professor1);
            Professor professor2 = new Professor();
            professor2.setNome("C");
            professor2.setIdade(20);
            professor2.setMatricula(2);
            professor2.incluir(conn);
            System.out.println(professor2);
            Professor professor3 = new Professor(3);
            professor3.carregar(conn);
            System.out.println(professor3);
            professor3.setNome("D");
            professor3.setIdade(25);
            professor3.atualizar(conn);
            professor3.carregar(conn);
            System.out.println(professor3);
            professor3.excluir(conn);
            System.out.println("Professor excluído: " + professor3);
        }
        catch(Exception e){
            e.printStackTrace();
            try{
                if(conn != null){
                    conn.rollback();
                }
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(conn != null){
                try{
                    conn.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }
}