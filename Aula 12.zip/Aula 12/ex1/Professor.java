package ex1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Professor{
    private String nome;
    private int idade;
    private int matricula;

    public Professor(String nome, int idade, int matricula){
        this.nome = nome;
        this.idade = idade;
        this.matricula = matricula;
    }

    public Professor(int matricula){
        this.matricula = matricula;
    }

    public Professor(){
        this.nome = "A";
        this.idade = 40;
        this.matricula = 0;
    }

    public String getNome(){
        return nome;
    }

    public int getIdade(){
        return idade;
    }

    public int getMatricula(){
        return matricula;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public void setIdade(int idade){
        this.idade = idade;
    }

    public void setMatricula(int matricula){
        this.matricula = matricula;
    }

    @Override
    public String toString(){
        return "Professor [Nome: " + nome + " | Idade: " + idade + " | Matricula: " + matricula + "]";
    }

    public void incluir(Connection conn){
        if(exists(conn)){
            System.out.println("Registro com matricula " + matricula + " já existe.");
            return;
        }
        String sqlInsert = "INSERT INTO Professor(nome, idade, matricula) VALUES (?, ?, ?)";
        PreparedStatement stm = null;

        try{
            stm = conn.prepareStatement(sqlInsert);
            stm.setString(1, getNome());
            stm.setInt(2, getIdade());
            stm.setInt(3, getMatricula());
            stm.execute();
        }
        catch (SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch (SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }

    public void excluir(Connection conn){
        String sqlDelete = "DELETE FROM Professor WHERE matricula = ?";
        PreparedStatement stm = null;

        try{
            stm = conn.prepareStatement(sqlDelete);
            stm.setInt(1, getMatricula());
            stm.execute();
        }
        catch(SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }

    public void atualizar(Connection conn){
        String sqlUpdate = "UPDATE Professor SET nome = ?, idade = ? WHERE matricula = ?";
        PreparedStatement stm = null;

        try{
            stm = conn.prepareStatement(sqlUpdate);
            stm.setString(1, getNome());
            stm.setInt(2, getIdade());
            stm.setInt(3, getMatricula());
            stm.execute();
        }
        catch(SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }

    public void carregar(Connection conn){
        String sqlSelect = "SELECT nome, idade FROM Professor WHERE matricula = ?";
        PreparedStatement stm = null;
        ResultSet rs = null;

        try{
            stm = conn.prepareStatement(sqlSelect);
            stm.setInt(1, getMatricula());
            rs = stm.executeQuery();
            if(rs.next()){
                this.setNome(rs.getString("nome"));
                this.setIdade(rs.getInt("idade"));
            }
            else{
                System.out.println("Professor com matricula " + matricula + " não encontrado.");
            }
        }
        catch(SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(rs != null){
                try{
                    rs.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }

    private boolean exists(Connection conn){
        String sqlCheck = "SELECT 1 FROM Professor WHERE matricula = ?";
        PreparedStatement stm = null;
        ResultSet rs = null;

        try{
            stm = conn.prepareStatement(sqlCheck);
            stm.setInt(1, getMatricula());
            rs = stm.executeQuery();
            return rs.next();
        }
        catch(SQLException e){
            e.printStackTrace();
            return false;
        }
        finally{
            if(rs != null){
                try{
                    rs.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }
}
