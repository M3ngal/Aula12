package ex2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Disciplina{
    private String nome;
    private ArrayList<Professor> professores;
    private String codigo;

    public Disciplina(String nome, ArrayList<Professor> professores, String codigo){
        this.nome = nome;
        this.professores = professores;
        this.codigo = codigo;
    }

    public Disciplina(String codigo){
        this.codigo = codigo;
        this.professores = new ArrayList<>();
    }

    public Disciplina(){
        this.nome = "A";
        this.professores = new ArrayList<>();
        this.codigo = "0";
    }

    public String getNome(){
        return nome;
    }

    public ArrayList<Professor> getProfessores(){
        return professores;
    }

    public String getCodigo(){
        return codigo;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public void setProfessores(ArrayList<Professor> professores){
        this.professores = professores;
    }

    public void setCodigo(String codigo){
        this.codigo = codigo;
    }

    @Override
    public String toString(){
        return "Disciplina [Nome: " + nome + " | Professores: " + professores + " | Codigo: " + codigo + "]";
    }

    public void incluir(Connection conn){
        String sqlInsert = "INSERT INTO Disciplina(nome, codigo) VALUES (?, ?)";
        PreparedStatement stm = null;

        try{
            conn.setAutoCommit(false);
            stm = conn.prepareStatement(sqlInsert);
            stm.setString(1, getNome());
            stm.setString(2, getCodigo());
            stm.execute();

            for(Professor professor : professores){
                String sqlInsertProfessor = "INSERT INTO Disciplina_Professor(codigo_disciplina, matricula_professor) VALUES (?, ?)";
                try(PreparedStatement stmProfessor = conn.prepareStatement(sqlInsertProfessor)){
                    stmProfessor.setString(1, getCodigo());
                    stmProfessor.setInt(2, professor.getMatricula());
                    stmProfessor.execute();
                }
            }
            conn.commit();
        }
        catch(Exception e){
            e.printStackTrace();
            try {
                conn.rollback();
            }
            catch(SQLException e1){
                e1.printStackTrace();
            }
        }
        finally{
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    e1.printStackTrace();
                }
            }
        }
    }

    public void excluir(Connection conn){
        String sqlDelete = "DELETE FROM Disciplina WHERE codigo = ?";
        PreparedStatement stm = null;

        try{
            conn.setAutoCommit(false);
            stm = conn.prepareStatement(sqlDelete);
            stm.setString(1, getCodigo());
            stm.execute();

            String sqlDeleteProfessores = "DELETE FROM Disciplina_Professor WHERE codigo_disciplina = ?";
            try(PreparedStatement stmProfessores = conn.prepareStatement(sqlDeleteProfessores)){
                stmProfessores.setString(1, getCodigo());
                stmProfessores.execute();
            }

            conn.commit();
        }
        catch(Exception e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                e1.printStackTrace();
            }
        }
        finally{
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    e1.printStackTrace();
                }
            }
        }
    }

    public void atualizar(Connection conn){
        String sqlUpdate = "UPDATE Disciplina SET nome = ? WHERE codigo = ?";
        PreparedStatement stm = null;

        try{
            conn.setAutoCommit(false);
            stm = conn.prepareStatement(sqlUpdate);
            stm.setString(1, getNome());
            stm.setString(2, getCodigo());
            stm.execute();

            String sqlDeleteProfessores = "DELETE FROM Disciplina_Professor WHERE codigo_disciplina = ?";
            try(PreparedStatement stmProfessores = conn.prepareStatement(sqlDeleteProfessores)){
                stmProfessores.setString(1, getCodigo());
                stmProfessores.execute();
            }

            for(Professor professor : professores){
                String sqlInsertProfessor = "INSERT INTO Disciplina_Professor(codigo_disciplina, matricula_professor) VALUES (?, ?)";
                try(PreparedStatement stmProfessor = conn.prepareStatement(sqlInsertProfessor)){
                    stmProfessor.setString(1, getCodigo());
                    stmProfessor.setInt(2, professor.getMatricula());
                    stmProfessor.execute();
                }
            }

            conn.commit();
        }
        catch(Exception e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                e1.printStackTrace();
            }
        }
        finally{
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    e1.printStackTrace();
                }
            }
        }
    }

    public void carregar(Connection conn){
        String sqlSelect = "SELECT nome FROM Disciplina WHERE codigo = ?";
        PreparedStatement stm = null;
        ResultSet rs = null;

        try{
            stm = conn.prepareStatement(sqlSelect);
            stm.setString(1, getCodigo());
            rs = stm.executeQuery();
            if(rs.next()){
                this.setNome(rs.getString("nome"));
            }

            String sqlSelectProfessores = "SELECT matricula_professor FROM Disciplina_Professor WHERE codigo_disciplina = ?";
            try(PreparedStatement stmProfessores = conn.prepareStatement(sqlSelectProfessores)){
                stmProfessores.setString(1, getCodigo());
                try(ResultSet rsProfessores = stmProfessores.executeQuery()){
                    while(rsProfessores.next()){
                        int matriculaProfessor = rsProfessores.getInt("matricula_professor");
                        Professor professor = new Professor(matriculaProfessor);
                        professor.carregar(conn);
                        professores.add(professor);
                    }
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                e1.printStackTrace();
            }
        }
        finally{
            if(rs != null){
                try{
                    rs.close();
                }
                catch(SQLException e1){
                    e1.printStackTrace();
                }
            }
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    e1.printStackTrace();
                }
            }
        }
    }
}