package ex2;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

public class Teste{
    public static void main(String[] args){
        Connection conn = null;

        try{
            ConexaoBD bd = new ConexaoBD();
            conn = bd.conectar();
            Professor professor1 = new Professor("B", 35, 1);
            professor1.incluir(conn);
            System.out.println("Incluído: " + professor1);
            Professor professor2 = new Professor("C", 20, 2);
            professor2.incluir(conn);
            System.out.println("Incluído: " + professor2);
            Professor professor3 = new Professor("D", 25, 3);
            professor3.incluir(conn);
            System.out.println("Incluído: " + professor3);
            ArrayList<Professor> professores = new ArrayList<>();
            professores.add(professor1);
            professores.add(professor2);
            Disciplina disciplina = new Disciplina("Matemática", professores, "MAT101");
            disciplina.incluir(conn);
            System.out.println("Incluída: " + disciplina);
            Disciplina disciplinaCarregada = new Disciplina("MAT101");
            disciplinaCarregada.carregar(conn);
            System.out.println("Carregada: " + disciplinaCarregada);
            disciplinaCarregada.setNome("Matemática Avançada");
            Professor professor4 = new Professor("E", 30, 4);
            professor4.incluir(conn);
            disciplinaCarregada.getProfessores().add(professor4);
            disciplinaCarregada.atualizar(conn);
            disciplinaCarregada.carregar(conn);
            System.out.println("Atualizada: " + disciplinaCarregada);
            disciplinaCarregada.excluir(conn);
            System.out.println("Disciplina excluída: " + disciplinaCarregada);
            professor1.excluir(conn);
            professor2.excluir(conn);
            professor3.excluir(conn);
            professor4.excluir(conn);
            System.out.println("Professores excluídos");

        }
        catch(Exception e){
            e.printStackTrace();
            try{
                if(conn != null){
                    conn.rollback();
                }
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(conn != null){
                try{
                    conn.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }
}