package ex3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Agencia {
    private String nome;
    private int numero;
    private int digito;

    public Agencia(String n, int nu, int d){
        nome = n;
        numero = nu;
        digito = d;
    }

    public String getNome(){
        return nome;
    }

    public int getNumero(){
        return numero;
    }

    public int getDigito(){
        return digito;
    }

    public void setNome(String n){
        nome = n;
    }

    public void setNumero(int nu){
        numero = nu;
    }

    public void setDigito(int d){
        digito = d;
    }

    @Override
    public String toString(){
        return "Agencia [Nome: " + nome + " | Número: " + numero + " | Dígito: " + digito + "]";
    }

    public void incluir(Connection conn) {
        String sqlInsert = "INSERT INTO Agencia(numero, digito, nome) VALUES (?, ?, ?)";
        PreparedStatement stm = null;

        try {
            if (existe(conn)) {
                System.out.println("A agência já existe.");
                return;
            }

            stm = conn.prepareStatement(sqlInsert);
            stm.setInt(1, getNumero());
            stm.setInt(2, getDigito());
            stm.setString(3, getNome());
            stm.execute();
            System.out.println("Agência incluída: " + this);
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } finally {
            if (stm != null) {
                try {
                    stm.close();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }

    private boolean existe(Connection conn) throws SQLException {
        String sqlQuery = "SELECT COUNT(*) FROM Agencia WHERE numero = ?";
        PreparedStatement stm = conn.prepareStatement(sqlQuery);
        stm.setInt(1, getNumero());
        ResultSet rs = stm.executeQuery();
        rs.next();
        int count = rs.getInt(1);
        rs.close();
        stm.close();
        return count > 0;
    }

    public void excluir(Connection conn){
        String sqlDelete = "DELETE FROM Agencia WHERE numero = ? AND digito = ?";
        PreparedStatement stm = null;

        try{
            stm = conn.prepareStatement(sqlDelete);
            stm.setInt(1, getNumero());
            stm.setInt(2, getDigito());
            stm.execute();
        }
        catch(SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }

    public void atualizar(Connection conn){
        String sqlUpdate = "UPDATE Agencia SET nome = ? WHERE numero = ? AND digito = ?";
        PreparedStatement stm = null;

        try{
            stm = conn.prepareStatement(sqlUpdate);
            stm.setString(1, getNome());
            stm.setInt(2, getNumero());
            stm.setInt(3, getDigito());
            stm.execute();
        }
        catch(SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }

    public void carregar(Connection conn){
        String sqlSelect = "SELECT nome FROM Agencia WHERE numero = ? AND digito = ?";
        PreparedStatement stm = null;
        ResultSet rs = null;

        try{
            stm = conn.prepareStatement(sqlSelect);
            stm.setInt(1, getNumero());
            stm.setInt(2, getDigito());
            rs = stm.executeQuery();
            if(rs.next()){
                this.setNome(rs.getString("nome"));
            }
            else{
                System.out.println("Agência não encontrada.");
            }
        }
        catch(SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(rs != null){
                try{
                    rs.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }
}
