package ex3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ContaCorrente {
    private int numero;
    private int digito;
    private Agencia agencia;
    private double saldo;

    public ContaCorrente(int n, int d, Agencia a, double s){
        numero = n;
        digito = d;
        agencia = a;
        saldo = s;
    }

    public static boolean ConfereNumero(int n, int d){
        int ch;
        int so = 0;
        if(n < 0 && n > 9999){
            return(false);
        }
        if(n < 999){
            ch = 0;
        }
        else{
            String cn = n + "";
            ch = Integer.parseInt(cn.substring(0,1));
            so += (ch * 4);
        }
        if(n < 99){
            ch = 0;
        }
        else{
            String cn = n + "";
            ch = Integer.parseInt(cn.substring(1,2));
            so += (ch * 6);
        }
        if(n < 9){
            ch = 0;
        }
        else{
            String cn = n + "";
            ch = Integer.parseInt(cn.substring(2,3));
            so += (ch * 8);
        }
        String cn = n + "";
        ch = Integer.parseInt(cn.substring(3,4));
        so += (ch * 2);
        so = so % 11;
        if(so == 10){
            so = 0;
        }
        return d == so;
    }

    public int getNumero(){
        return numero;
    }

    public int getDigito(){
        return digito;
    }

    public Agencia getAgencia(){
        return agencia;
    }

    public double getSaldo(){
        return saldo;
    }

    public void setNumero(int n){
        numero = n;
    }

    public void setDigito(int d){
        digito = d;
    }

    public void setAgencia(Agencia a){
        agencia = a;
    }

    public void setSaldo(double s){
        saldo = s;
    }

    public double depositar(double s){
        saldo += s;
        return saldo;
    }

    public double sacar(double s){
        double c = saldo;
        saldo -= s;
        if(saldo < 0) {
            System.out.print("Saldo indisponível para saque.\n");
            saldo = c;
            return 0;
        }
        return saldo;
    }

    public double consultarSaldo(){
        return saldo;
    }

    public void imprimirSaldo(int n, int d, int na, int da, double saldo){
        System.out.print("Conta corrente: " + n + " Dígito: " + d +"\nAgência: " + na + " Dígito: " + da +"\nSaldo da conta corrente: " + saldo);
    }

    public void incluir(Connection conn) {
        String sqlInsert = "INSERT INTO ContaCorrente(numero, digito, saldo, agencia_numero) VALUES (?, ?, ?, ?)";
        PreparedStatement stm = null;

        try {
            if (existe(conn)) {
                System.out.println("A conta corrente já existe.");
                return;
            }

            stm = conn.prepareStatement(sqlInsert);
            stm.setInt(1, getNumero());
            stm.setInt(2, getDigito());
            stm.setDouble(3, getSaldo());
            stm.setInt(4, getAgencia().getNumero());
            stm.execute();
            System.out.println("Conta corrente incluída: " + this);
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } finally {
            if (stm != null) {
                try {
                    stm.close();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }

    private boolean existe(Connection conn) throws SQLException {
        String sqlQuery = "SELECT COUNT(*) FROM ContaCorrente WHERE numero = ?";
        PreparedStatement stm = conn.prepareStatement(sqlQuery);
        stm.setInt(1, getNumero());
        ResultSet rs = stm.executeQuery();
        rs.next();
        int count = rs.getInt(1);
        rs.close();
        stm.close();
        return count > 0;
    }


    public void excluir(Connection conn){
        String sqlDelete = "DELETE FROM ContaCorrente WHERE numero = ? AND digito = ?";
        PreparedStatement stm = null;

        try{
            stm = conn.prepareStatement(sqlDelete);
            stm.setInt(1, getNumero());
            stm.setInt(2, getDigito());
            stm.execute();
        }
        catch(SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }

    public void atualizar(Connection conn){
        String sqlUpdate = "UPDATE ContaCorrente SET saldo = ? WHERE numero = ? AND digito = ?";
        PreparedStatement stm = null;

        try{
            stm = conn.prepareStatement(sqlUpdate);
            stm.setDouble(1, getSaldo());
            stm.setInt(2, getNumero());
            stm.setInt(3, getDigito());
            stm.execute();
        }
        catch(SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }

    public void carregar(Connection conn){
        String sqlSelect = "SELECT saldo FROM ContaCorrente WHERE numero = ? AND digito = ?";
        PreparedStatement stm = null;
        ResultSet rs = null;

        try{
            stm = conn.prepareStatement(sqlSelect);
            stm.setInt(1, getNumero());
            stm.setInt(2, getDigito());
            rs = stm.executeQuery();
            if(rs.next()){
                setSaldo(rs.getDouble("saldo"));
            }
            else{
                System.out.println("Conta corrente não encontrada.");
            }
        }
        catch(SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(rs != null){
                try{
                    rs.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }
}