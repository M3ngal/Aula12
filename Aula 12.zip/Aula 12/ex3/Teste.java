package ex3;

import java.sql.Connection;
import java.sql.SQLException;

public class Teste {
    public static void main(String[] args) {
        Connection conn = null;
        try {
            ConexaoBD bd = new ConexaoBD();
            conn = bd.conectar();

            Agencia agencia = new Agencia("Agência Centro", 1234, 5);
            agencia.incluir(conn);
            System.out.println("Agência incluída: " + agencia);
            System.out.println();

            Cliente cliente = new Cliente("123.456.789-00", "João", null);
            cliente.incluir(conn);
            System.out.println("Cliente incluído: " + cliente);
            System.out.println();

            ContaCorrente contaCorrente = new ContaCorrente(987654, 1, agencia, 1000.0);
            contaCorrente.incluir(conn);
            System.out.println("Conta corrente incluída: " + contaCorrente);
            System.out.println();

            Cliente clienteConsultado = new Cliente("123.456.789-00", "João", null);
            clienteConsultado.carregar(conn);
            System.out.println("Cliente consultado: " + clienteConsultado);
            System.out.println();

            if (clienteConsultado.getNome() != null) {
                clienteConsultado.setNome("João da Silva");
                clienteConsultado.atualizar(conn);
                System.out.println("Cliente atualizado: " + clienteConsultado);
                System.out.println();
            }
            else {
                System.out.println("Cliente não encontrado para atualização.");
                System.out.println();
            }

            if (clienteConsultado.getNome() != null) {
                clienteConsultado.excluir(conn);
                System.out.println("Cliente excluído.");
                System.out.println();
            } else {
                System.out.println("Cliente não encontrado para exclusão.");
                System.out.println();
            }

        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException e1) {
                System.out.print(e1.getStackTrace());
            }
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e1) {
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }
}