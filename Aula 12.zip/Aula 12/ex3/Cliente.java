package ex3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Cliente {
    private String nome;
    private String cpf;
    private ContaCorrente conta;

    public Cliente(String n, String c, ContaCorrente ct){
        nome = n;
        cpf = c;
        conta = ct;
    }

    public String getNome(){
        return nome;
    }

    public String getCpf(){
        return cpf;
    }

    public ContaCorrente getConta(){
        return conta;
    }

    public void setNome(String n){
        nome = n;
    }

    public void setCpf(String c){
        cpf = c;
    }

    public void setConta(ContaCorrente ct){
        conta = ct;
    }

    @Override
    public String toString(){
        return "Cliente [Nome: " + nome + " | CPF: " + cpf + " | Conta: " + conta + "]";
    }

    public void incluir(Connection conn){
        String sqlInsert = "INSERT INTO Cliente(nome, cpf) VALUES (?, ?)";
        PreparedStatement stm = null;

        try{
            stm = conn.prepareStatement(sqlInsert);
            stm.setString(1, getNome());
            stm.setString(2, getCpf());
            stm.execute();
        }
        catch(SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }

    public void excluir(Connection conn){
        String sqlDelete = "DELETE FROM Cliente WHERE cpf = ?";
        PreparedStatement stm = null;

        try{
            stm = conn.prepareStatement(sqlDelete);
            stm.setString(1, getCpf());
            stm.execute();
        }
        catch(SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }

    public void atualizar(Connection conn){
        String sqlUpdate = "UPDATE Cliente SET nome = ? WHERE cpf = ?";
        PreparedStatement stm = null;

        try{
            stm = conn.prepareStatement(sqlUpdate);
            stm.setString(1, getNome());
            stm.setString(2, getCpf());
            stm.execute();
        }
        catch(SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }

    public void carregar(Connection conn){
        String sqlSelect = "SELECT nome FROM Cliente WHERE cpf = ?";
        PreparedStatement stm = null;
        ResultSet rs = null;

        try{
            stm = conn.prepareStatement(sqlSelect);
            stm.setString(1, getCpf());
            rs = stm.executeQuery();
            if(rs.next()){
                this.setNome(rs.getString("nome"));
            }
            else{
                System.out.println("Cliente não encontrado.");
            }
        }
        catch(SQLException e){
            e.printStackTrace();
            try{
                conn.rollback();
            }
            catch(SQLException e1){
                System.out.print(e1.getStackTrace());
            }
        }
        finally{
            if(rs != null){
                try{
                    rs.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
            if(stm != null){
                try{
                    stm.close();
                }
                catch(SQLException e1){
                    System.out.print(e1.getStackTrace());
                }
            }
        }
    }
}
